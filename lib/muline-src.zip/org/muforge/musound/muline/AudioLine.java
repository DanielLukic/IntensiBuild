package org.muforge.musound.muline;

/* ================================================================
 * MuSound MuLine - Sound library for MIDP2/MMAPI
 * Copyright (C) 2004 Guillaume Legris
 * 
 * libFLAC - Free Lossless Audio Codec library
 * Copyright (C) 2001,2002,2003  Josh Coalson
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA  02111-1307, USA.
 * ================================================================
 */

import java.io.IOException;


/**
 * A line is an element of the digital audio "pipeline", such as a mixer,
 * an input or output port, or a data path into or out of a mixer. 
 * 
 * @author Guillaume Legris
 */
public interface AudioLine {

	
	/**
	 * Opens the line. It acquires the appropriate system resources.
	 * 
	 * @throws IOException if the line cannot be opened
	 */
	public void open() throws IOException;
	
	/**
	 * Closes the line and released system resources it used.
	 * 
	 * @throws IOException if the line cannot be opened
	 */
	public void close();
	
	/**
	 * Obtains the number of bytes of data that can be written to the buffer
	 * without blocking.
	 * 
	 * @return the amount of data available (in bytes)
	 */
	public int available();
	
	/**
	 * Starts the line.
	 */
	public void start();
	
	/**
	 * Stops the line.
	 */
	public void stop();
	
	/**
	 * Flushes queued data from the line. The flushed data is discarded. 
	 */
	public void flush();
	
	/**
	 * Indicates whether the line is running.
	 * @return true if the line is running, otherwise false
	 */
	public boolean isRunning();
	
	/**
	 * Indicates whether the line is open.
	 * @return true if the line is open, otherwise false
	 */
	public boolean isOpen();
	
	/**
	 * Gets the format of the line audio data.
	 * 
	 * @return the format of the line audio data
	 */
	public AudioFormat getFormat();
	
	/**
	 * Gets the internal buffer size (in bytes).
	 * 
	 * @return the buffer size
	 */
	public int getBufferSize();
	
	/**
	 * Obtains the current position in the audio data, in microseconds.
	 * 
	 * @return the number of microseconds of data processed since the line was 
	 *         opened
	 */
	public long getMicrosecondPosition();
	
	/**
	 * Obtains the current position in the audio data, in sample frames.
	 * 
	 * @return the number of frames already processed since the line was opened 
	 */
	public int getFramePosition();
	
	/**
	 * Drains buffered data from the line until the line's internal buffer
	 * has been emptied.
	 */
	public void drain();

}