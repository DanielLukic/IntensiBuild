package org.muforge.musound.muline;

/* ================================================================
 * MuSound MuLine - Sound library for MIDP2/MMAPI
 * Copyright (C) 2004 Guillaume Legris
 * 
 * libFLAC - Free Lossless Audio Codec library
 * Copyright (C) 2001,2002,2003  Josh Coalson
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA  02111-1307, USA.
 * ================================================================
 */

import java.io.IOException;
import java.io.OutputStream;

/**
 * @author Guillaume Legris
 */
public interface AudioFormatWriter {
   
    /**
     * Creates a writer with a specified audio format.
     * 
     * @param os the output stream where to write audio data.
     * @param format the audio format of the audio stream.
     * @param maxDataBlockSize 
     * 	 the maximum size (in samples) of the written data when write() 
     *   method is called.
     * @param length the length (in samples) of the WAV file.
     */
    public void initialize(OutputStream os, AudioFormat format, int maxDataBlockSize,
            int length);
    
    /**
     * Writes audio data.
     * 
     * @param data the data to be written.
     * @param offset the start offset in the data.
     * @param size the number of bytes to write. 
     * @throws IOException if error while writing.
     */
    public void writeAudioData(byte[] data, int offset, int size)
            throws IOException;
    
    /**
     * Writes a complete header.
     * 
     ** @throws IOException if error when writing the header. 
     */
    public void writeHeader() throws IOException;
    
    /**
     * Gets the content type of the media that's writed by this writer.
     * 
     * @return the content type of the media that's writed by this writer.
     */
    public String getContentType();
    
    /**
     * Writes silence to the stream.
     * 
     * @param size the size (in bytes) of the data to be written.
     */
    public void writeSilence(int size) throws IOException;
    
    
}