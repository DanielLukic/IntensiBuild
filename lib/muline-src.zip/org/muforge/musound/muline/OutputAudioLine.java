package org.muforge.musound.muline;

/* ================================================================
 * MuSound MuLine - Sound library for MIDP2/MMAPI
 * Copyright (C) 2004 Guillaume Legris
 * 
 * libFLAC - Free Lossless Audio Codec library
 * Copyright (C) 2001,2002,2003  Josh Coalson
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA  02111-1307, USA.
 * ================================================================
 */

import java.io.IOException;

/**
 * An output audio line is a audio line to which data may be written. 
 * 
 * @author Guillaume Legris
 */
public interface OutputAudioLine extends AudioLine {

	/**
	 * Opens the line with the specified format, causing the line to acquire any
	 * required system resources.
	 */
	public void open(AudioFormat format) throws IOException;

	/**
	 * Opens the line with the specified format and buffer size,
	 * causing the line to acquire any required system resources.
	 * 
	 * @param format
	 * @param bufferSize
	 */
	public void open(AudioFormat format, int bufferSize) throws IOException;

	/**
	 * Writes data to the line
	 * 
	 * @param b the bytes to be written to the line
	 * @param off offset where to get data in the byte array
	 * @param len number of bytes to write to the line
	 * @return the number of bytes actually written
	 * @throws IOException if data can't be written
	 */
	public int write(byte[] b, int off, int len) throws IOException;

}