package org.muforge.musound.muline;

/* ================================================================
 * MuSound MuLine - Sound library for MIDP2/MMAPI
 * Copyright (C) 2004 Guillaume Legris
 * 
 * libFLAC - Free Lossless Audio Codec library
 * Copyright (C) 2001,2002,2003  Josh Coalson
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA  02111-1307, USA.
 * ================================================================
 */

/**
 * AudioFormat is the class that specifies arrangement of data
 * in a sound stream.
 * 
 * @author Guillaume Legris
 *
 */
public class AudioFormat {

    public int sampleRate;
    public int bitsPerSample;
    public int channels;
    public boolean signed;
    public boolean bigEndian;

    /**
     * 
     * @param sampleRate the sample rate in Hz
     * @param bitsPerSample the number of bits per sample.
     * @param channels the number of channels.
     * @param signed if true, data are signed; otherwise, they are unsigned.
     * @param bigEndian if true, data are in the big endian format; 
     *        otherwise, data are in the little endian format.
     */
    public AudioFormat(int sampleRate, int bitsPerSample, int channels,
            boolean signed, boolean bigEndian) {
        this.sampleRate = sampleRate;
        this.bitsPerSample = bitsPerSample;
        this.channels = channels;
        this.signed = signed;
        this.bigEndian = bigEndian;
    }

    /**
     * Tests if the given audio format matches with this one.
     * @param format the audio format to test.
     * @return true if the given format matches this one, otherwise false
     */
    public boolean matches(AudioFormat format) {

        if (format.sampleRate != sampleRate) {
            return false;
        }

        if (format.bitsPerSample != bitsPerSample) {
            return false;
        }

        if (format.channels != channels) {
            return false;
        }

        if (format.signed != signed) {
            return false;
        }

        if (format.bigEndian != bigEndian) {
            return false;
        }

        return true;
    }

}