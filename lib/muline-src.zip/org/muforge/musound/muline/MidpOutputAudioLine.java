package org.muforge.musound.muline;

/* ================================================================
 * MuSound MuLine - Sound library for MIDP2/MMAPI
 * Copyright (C) 2004 Guillaume Legris
 * 
 * libFLAC - Free Lossless Audio Codec library
 * Copyright (C) 2001,2002,2003  Josh Coalson
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA  02111-1307, USA.
 * ================================================================
 */
import java.io.IOException;
import java.io.OutputStream;

import javax.microedition.media.Manager;
import javax.microedition.media.MediaException;
import javax.microedition.media.Player;

/**
 * <p>MidpOutputAudioLine provides a method for writing audio 
 * data to the audio line's buffer.<p>
 * 
 * <p>The API contract is the same than for
 * <a href="http://java.sun.com/j2se/1.4.2/docs/api/javax/sound/sampled/SourceDataLine.html">javax.sound.sampled.SourceDataLine</a>
 * </p>
 * 
 * @author Guillaume Legris
 */
public class MidpOutputAudioLine implements OutputAudioLine {

    /** 
     * Default audio format:
     * PCM, 8000 Hz, 8 bits, mono, signed, little endian 
     */
    private AudioFormat format = new AudioFormat(8000, 8, 1, true, false);

    /** Sound buffer. Default to 200 ms */
    private int bufferSize = format.sampleRate * format.channels
            * ((format.bitsPerSample + 7) / 8) / 5;

    private Player player;

    private AudioFormatWriter writer = new PCMWavWriter();

    private PipedOutputStream pos;
    private PipedInputStream pis;

    private boolean open = false;
    private boolean running = false;

    private long startTime;
    private int writtenBytes;

    private final OutputStream lineOutputStream = new LineOutputStream(this);

    public MidpOutputAudioLine() {
    }

    /*
     * @see OutputAudioLine#open(AudioFormat)
     */
    public void open(AudioFormat format) throws IOException {
        this.format = format;
        open();
    }

    /*
     * @see OutputAudioLine#open(AudioFormat, int)
     */
    public void open(AudioFormat format, int bufferSize) throws IOException {
        this.format = format;
        this.bufferSize = bufferSize;
        open();
    }

    /*
     * @see AudioLine#open()
     */
    public void open() throws IOException {

        // Create pipe
        pos = new PipedOutputStream();
        pis = new PipedInputStream(bufferSize);
        pos.connect(pis);

        int maxBlockSize = format.sampleRate * format.channels
                * ((format.bitsPerSample + 7) / 8);
        int maxLength = Integer.MAX_VALUE / maxBlockSize;

        // Initialize audio format writer
        writer.initialize(pos, format, format.sampleRate, maxLength
                * format.sampleRate);

        writer.writeHeader();

        try {
            player = Manager.createPlayer(pis, writer.getContentType());

            //System.out.println("Prefetching...");
            player.prefetch();
            //System.out.println("Prefetched");
        } catch (Exception e) {
            throw new IOException("Can't open the line: " + e.getMessage());
        }

        open = true;

    }

    /*
     * @see AudioLine#isOpen()
     */
    public boolean isOpen() {
        return open;
    }

    /*
     * @see OutputAudioLine#write(byte[], int, int)
     */
    public int write(byte[] b, int off, int len) {

        /* TODO
         * Ensure the the end of the wav stream has not been reached
         * and create a new player if needed.
         */

        /* TODO 
         * If the line is closed, stopped, or flushed before the requested 
         * amount has been written, the method no longer blocks, but returns the
         * number of bytes written thus far.
         */

        //int availableWriteSpace = pis.freespace();
        if (open) {

            try {

                //pos.write(b, off, len);
                writer.writeAudioData(b, off, len);

            } catch (IOException e) {
                e.printStackTrace();
                return 0;
            }

            writtenBytes += len;

            return len;

        } else {
            return len;
        }

    }

    /*
     * @see AudioLine#available()
     */
    public int available() {
        // TODO Write implementation 
        return pis.freespace();
    }

    /*
     * @see AudioLine#start()
     */
    public void start() {

        try {

            startTime = System.currentTimeMillis();
            player.start();
            running = true;

        } catch (MediaException e) {
            e.printStackTrace();
            running = false;
            open = false;
        }

    }

    /*
     * @see AudioLine#stop()
     */
    public void stop() {

        try {
            player.stop();
        } catch (MediaException e) {
            e.printStackTrace();
            open = false;
        }

        running = false;

    }

    /*
     * @see AudioLine#flush()
     */
    public void flush() {
        pis.reset();
    }

    /*
     * @see AudioLine#isRunning()
     */
    public boolean isRunning() {
        return running;
    }

    /*
     * @see AudioLine#getFormat()
     */
    public AudioFormat getFormat() {
        return format;
    }

    /*
     * @see AudioLine#getBufferSize()
     */
    public int getBufferSize() {
        // TODO Write implementation 
        return pis.getBufferSize();
    }

    /*
     * @see AudioLine#getMicrosecondPosition()
     */
    public long getMicrosecondPosition() {
        //return player.getMediaTime();
        return (System.currentTimeMillis() - startTime);
    }

    /*
     * @see AudioLine#getFramePosition()
     */
    public int getFramePosition() {
        return writtenBytes
                / (format.channels * ((format.bitsPerSample + 7) / 8));
    }

    /*
     * @see AudioLine#drain()
     */
    public void drain() {

        try {

            pos.flush();

            // FIXME Drain during 2 seconds (?)

            /*int bufferSize100ms = format.sampleRate * format.channels
                    * ((format.bitsPerSample + 7) / 8) / 10;

            for (int i = 0; i < 20; i++) {
                writer.writeSilence(bufferSize100ms);
            }*/
            

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /*
     * @see AudioLine#close()
     */
    public void close() {
        
        open = false;
        running = false;
        
        try {
            pos.close();
        } catch (IOException e) {
            // Do nothing
        }
        
        player.close();
        
    }

    /**
     * Gets an OutputStream object to write to the line.
     * 
     * @return an output stream.
     */
    public OutputStream getOutputStream() {
        return lineOutputStream;
    }

}