package org.muforge.musound.muline;

/* ================================================================
 * MuSound MuLine - Sound library for MIDP2/MMAPI
 * Copyright (C) 2004 Guillaume Legris
 * 
 * libFLAC - Free Lossless Audio Codec library
 * Copyright (C) 2001,2002,2003  Josh Coalson
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA  02111-1307, USA.
 * ================================================================
 */

import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.muforge.musound.muline.AudioFormat;

/**
 * <p>PCMWavWriter writes an output stream in the WAV format from a PCM audio source.</p>
 * 
 * <p>The writer takes an audio stream as input. It will adapt as well as possible to the 
 * audio format of the stream. For that, it contains a built-in audio converter.
 * For better performance (it avoids conversions), the recommended audio formats are :
 * <ul>
 * <li>8 bits, unsigned</li>
 * <li>16 bits, signed, little endian</li>
 * <li>24 bits, signed, little endian</li>
 * </ul>
 * </p>
 * 
 * <p>Written with help of these documentations:
 * <ul>
 * <li>http://www.sonicspot.com/guide/wavefiles.html</li>
 * <li>http://ccrma.stanford.edu/courses/422/projects/WaveFormat/</li>
 * </ul></p>
 * 
 * @author Josh Coalson
 * @author Guillaume Legris
 */
public class PCMWavWriter implements AudioFormatWriter {

    public static final int MAX_CHANNELS = 8;
    public static final int MAX_BLOCK_SIZE = 65535;
    
    public static final String CONTENT_TYPE = "audio/X-wav";

    private int totalSamples;

    private int maxDataBlockSize;

    private byte[] s8buffer;
    private int samplesProcessed = 0;
    private int frameCounter = 0;

    private DataOutput os;

    private AudioFormat audioFormat;
    
    private boolean formatConversionActivated = true;
    
    public PCMWavWriter() {
        
    }

    /**
     * Creates a wave writer with a specified audio format.
     * 
     * @param os the output stream where to write audio data.
     * @param format the audio format of the audio stream.
     * @param maxDataBlockSize 
     * 	 the maximum size (in samples) of the written data when write() 
     *   method is called.
     * @param length the length (in samples) of the WAV file.
     */
    public PCMWavWriter(OutputStream os, AudioFormat format, int maxDataBlockSize,
            int length) {
        initialize(os, format, maxDataBlockSize, length);
    }
    
    /**
     * Initialize a wave writer with a specified audio format.
     * 
     * @param os the output stream where to write audio data.
     * @param format the audio format of the audio stream.
     * @param maxDataBlockSize 
     * 	 the maximum size (in samples) of the written data when write() 
     *   method is called.
     * @param length the length (in samples) of the WAV file.
     */
    public void initialize(OutputStream os, AudioFormat format, int maxDataBlockSize,
            int length) {
        this.os = new DataOutputStream(os);
        this.audioFormat = format;
        this.maxDataBlockSize = maxDataBlockSize;
        this.totalSamples = length;

        s8buffer = new byte[maxDataBlockSize * format.channels
                * ((format.bitsPerSample + 7) / 8)];
    }


    /**
     * Write a WAV file header.
     * 
     * @throws IOException if error when writing to output string.
     */
    public void writeWaveRiffHeader() throws IOException {

        long dataSize = totalSamples * audioFormat.channels
                * ((audioFormat.bitsPerSample + 7) / 8);
        //long dataSize = totalSamples * channels * audioFormat.bitsPerSample / 8;

        /* Wave File Header - RIFF Type Chunk */

        // Chunk ID
        os.write("RIFF".getBytes());
        // Chunk Data Size ( = filesize - 8 )
        writeInt((int) dataSize + 36);
        // RIFF Type: WAVE
        os.write("WAVE".getBytes());
    }

    /**
     * Writes a complete WAV header.
     * 
     ** @throws IOException if error when writing to output string. 
     */
    public void writeHeader() throws IOException {
        writeWaveRiffHeader();
        writeFormatChunkHeader();
        writeDataChunkHeader();
    }

    /**
     * Writes a format chunk header.
     * 
     * @throws IOException
     *             Thrown if error writing to output string.
     */
    public void writeFormatChunkHeader() throws IOException {

        /* Format Chunk - "fmt " */

        // Format chunk id
        os.write("fmt ".getBytes());
        // Chunk Data Size ( = 16 )
        os.write(new byte[]{0x10, 0x00, 0x00, 0x00});
        // Compression code : PCM/uncompressed ( = 1 )
        os.write(new byte[]{0x01, 0x00});
        // Number of channels
        writeShort(audioFormat.channels);
        // Sample rate
        writeInt(audioFormat.sampleRate);
        // Average bytes per second ( = sampleRate * blockAlign )
        // blockAlign = audioFormat.channels * audioFormat.bitsPerSample / 8;
        writeInt(audioFormat.sampleRate * audioFormat.channels
                * ((audioFormat.bitsPerSample + 7) / 8));
        // Block align
        writeShort(audioFormat.channels * ((audioFormat.bitsPerSample + 7) / 8));
        // Significant bits per sample
        writeShort(audioFormat.bitsPerSample);

    }

    /**
     * Writes a data chunk header.
     * 
     * @throws IOException
     *             Thrown if error writing to output string.
     */
    public void writeDataChunkHeader() throws IOException {

        long chunkSize = totalSamples * audioFormat.channels
                * ((audioFormat.bitsPerSample + 7) / 8);

        /* Data Chunk - "data" */

        // Chunk ID
        os.write("data".getBytes());
        // Chunk size
        writeInt((int) chunkSize); // data size

    }

    /**
     * Writes audio data.
     * 
     * @param data the data to be written.
     * @param offset the start offset in the data.
     * @param size the number of bytes to write. 
     * @throws IOException if error while writing.
     */
    public void writeAudioData(byte[] data, int offset, int size) throws IOException {

        //if ((offset + size) >= data.length) {
        //	throw new IndexOutOfBoundsException("");
        //}
        
        // Write raw data if the converter is not activated.
        if (!isFormatConversionActivated()) {
            os.write(data, offset, size);
            return;
        }

        // Do conversion
        
        int wideSamples = size;
        int wideSample;
        int sampleIndex = 0;
        int channel;

        if (wideSamples > 0) {
            samplesProcessed += size;
            frameCounter++;

            if (audioFormat.bitsPerSample == 8) {

                if (audioFormat.signed) {

                    while (sampleIndex < wideSamples) {
                        for (channel = 0; channel < audioFormat.channels; channel++) {
                            // Unsign byte
                            s8buffer[sampleIndex] = (byte) (data[offset
                                    + sampleIndex++] + 0x80);
                        }
                    }
                    os.write(s8buffer, 0, sampleIndex);
                } else {
                    os.write(data, offset, size);
                }

            } else if (audioFormat.bitsPerSample == 16) {

                // Sign data if audio format is unsigned
                if (!audioFormat.signed) {

                    if (audioFormat.bigEndian) {

                        while (sampleIndex < wideSamples) {
                            for (channel = 0; channel < audioFormat.channels; channel++) {
                                s8buffer[sampleIndex] = (byte) (data[offset
                                        + sampleIndex++ + 0x80]);
                                s8buffer[sampleIndex] = (byte) (data[offset
                                        + sampleIndex++]);
                            }
                        }

                    } else {

                        while (sampleIndex < wideSamples) {
                            for (channel = 0; channel < audioFormat.channels; channel++) {
                                s8buffer[sampleIndex] = (byte) (data[offset
                                        + sampleIndex++]);
                                s8buffer[sampleIndex] = (byte) (data[offset
                                        + sampleIndex++] + 0x80);
                            }
                        }

                    } // if bigEndian

                    os.write(s8buffer, 0, sampleIndex);

                } else {
                    if (audioFormat.bigEndian) {

                        // Swap bytes
                        while (sampleIndex < wideSamples) {
                            for (channel = 0; channel < audioFormat.channels; channel++) {
                                s8buffer[sampleIndex] = (byte) (data[offset
                                        + sampleIndex++ + 1]);
                                s8buffer[sampleIndex] = (byte) (data[offset
                                        + sampleIndex++ - 1]);
                            }
                        }
                        os.write(s8buffer, 0, sampleIndex);

                    } else {

                        os.write(data, offset, size);

                    }

                } // if

            } else if (audioFormat.bitsPerSample == 24) {

                // Sign data if audio format is unsigned
                if (!audioFormat.signed) {

                    if (audioFormat.bigEndian) {

                        for (sampleIndex = wideSample = 0; wideSample < wideSamples; wideSample++) {
                            for (channel = 0; channel < audioFormat.channels; channel++) {

                                s8buffer[sampleIndex] = (byte) (data[offset
                                        + sampleIndex++] + 0x80);
                                s8buffer[sampleIndex] = (byte) (data[offset
                                        + sampleIndex++]);

                                s8buffer[sampleIndex] = (byte) (data[offset
                                        + sampleIndex++]);

                            }
                        }

                    } else {

                        for (sampleIndex = wideSample = 0; wideSample < wideSamples; wideSample++) {
                            for (channel = 0; channel < audioFormat.channels; channel++) {

                                s8buffer[sampleIndex] = (byte) (data[offset
                                        + sampleIndex++]);
                                s8buffer[sampleIndex] = (byte) (data[offset
                                        + sampleIndex++]);

                                s8buffer[sampleIndex] = (byte) (data[offset
                                        + sampleIndex++] + 0x80);

                            }
                        }

                    } // if bigEndian

                    os.write(s8buffer, 0, sampleIndex);

                } else {
                    if (audioFormat.bigEndian) {
                        // Swap bytes
                        while (sampleIndex < wideSamples) {
                            for (channel = 0; channel < audioFormat.channels; channel++) {
                                s8buffer[sampleIndex] = (byte) (data[offset
                                        + sampleIndex++ + 2]);
                                s8buffer[sampleIndex] = (byte) (data[offset
                                        + sampleIndex++]);
                                s8buffer[sampleIndex] = (byte) (data[offset
                                        + sampleIndex++ - 2]);
                            }
                        }
                    } else {
                        os.write(data, offset, size);
                    }

                }

            } // if

        } // if
    }
    
    /**
     * Gets the content type of the media that's writed by this writer:  
     * <code>audio/x-wav</code>
     */
    public String getContentType() {
        return CONTENT_TYPE;
    }
    
    /**
     * Returns if the built-in format conversion is activated.
     * 
     * @return true if the conversion is activated, false otherwise
     */
    public boolean isFormatConversionActivated() {
        return formatConversionActivated;
    }
    
    /**
     * Activates/Desactivates the format conversion.
     * 
     * @param activated true if the conversion must be activated, false otherwise
     */
    public void setFormatConversionActivated(boolean activated) {
        this.formatConversionActivated = activated;
    }
    

    /*
     * @see org.muforge.musound.muline.AudioFormatWriter#writeSilence(int)
     */
    public void writeSilence(int size) throws IOException {
        
        // FIXME Do real silence ...
        
        byte[] drainBuffer = new byte[size];

        for (int i = 0; i < 20; i++) {
            os.write(drainBuffer);
        }
        
    }

    /**
     * Writes an integer to the output stream in a little endian format.
     * @param val the integer to be written
     * @throws IOException
     */
    private void writeInt(int val) throws IOException {
        os.writeByte(val & 0xff);
        os.writeByte((val >> 8) & 0xff);
        os.writeByte((val >> 16) & 0xff);
        os.writeByte((val >> 24) & 0xff);
    }

    /**
     * Writes a short to the output stream in a little endian format.
     * @param val the short to be written
     * @throws IOException
     */
    private void writeShort(int val) throws IOException {
        os.writeByte(val & 0xff);
        os.writeByte((val >> 8) & 0xff);
    }


    
}