package org.muforge.musound.muline;

/* ================================================================
 * MuSound MuLine - Sound library for MIDP2/MMAPI
 * Copyright (C) 2004 Guillaume Legris
 * 
 * libFLAC - Free Lossless Audio Codec library
 * Copyright (C) 2001,2002,2003  Josh Coalson
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA  02111-1307, USA.
 * ================================================================
 */

import java.io.IOException;
import java.io.OutputStream;

/**
 * An utility class to obtain an OutputStream from an OutputAudioLine.
 * 
 * @author Guillaume Legris
 */
public class LineOutputStream extends OutputStream {

    
    private OutputAudioLine line;
    
    public LineOutputStream(OutputAudioLine line) {
        this.line = line;
    }
    
    /* 
     * @see java.io.OutputStream#write(int)
     */
    public void write(int b) throws IOException {
        byte[] bytes = { (byte) b };
        write(bytes, 0, 0);
    }
    
    /* 
     * @see java.io.OutputStream#write(byte[])
     */
    public void write(byte[] b) throws IOException {
        write(b, 0, 0);
    }
    
    /* 
     * @see java.io.OutputStream#write(byte[], int, int)
     */
	public void write(byte[] b, int off, int len) throws IOException {
	    line.write(b, off, len);
	}
	
	 /* 
     * @see java.io.OutputStream#flush()
     */
	public void flush() {
	    line.drain();
	}
	
	/* 
     * @see java.io.OutputStream#close()
     */
	public void close() {
	    line.close();
	}
	
}
